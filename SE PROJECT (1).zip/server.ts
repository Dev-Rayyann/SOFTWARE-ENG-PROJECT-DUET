import express from "express";
import path from "path";
import { fileURLToPath } from "url";
import { createServer as createViteServer } from "vite";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Mock Database (Simulating SQL)
  let employees = [
    { id: "1", name: "Ahmed Khan", department: "Engineering", salary: 75000 },
    { id: "2", name: "Sara Ahmed", department: "HR", salary: 65000 },
    { id: "3", name: "Zubair Ali", department: "Operations", salary: 55000 },
  ];

  let payrollRecords = [
    { id: "101", employeeId: "1", bonus: 5000, tax: 7500, netSalary: 72500, timestamp: new Date().toISOString() },
  ];

  // API Routes
  app.get("/api/employees", (req, res) => {
    res.json(employees);
  });

  app.post("/api/employees", (req, res) => {
    const newEmployee = {
      id: Date.now().toString(),
      ...req.body
    };
    employees.push(newEmployee);
    res.status(201).json(newEmployee);
  });

  app.delete("/api/employees/:id", (req, res) => {
    employees = employees.filter(e => e.id !== req.params.id);
    res.status(204).send();
  });

  app.post("/api/calculate-salary", (req, res) => {
    const { employeeId, basicSalary, bonus, tax } = req.body;
    const netSalary = Number(basicSalary) + Number(bonus) - Number(tax);
    
    const record = {
      id: "PR-" + Date.now(),
      employeeId,
      bonus,
      tax,
      netSalary,
      timestamp: new Date().toISOString()
    };
    payrollRecords.push(record);
    res.json(record);
  });

  app.get("/api/payroll", (req, res) => {
    res.json(payrollRecords);
  });

  app.get("/api/health", (req, res) => {
    res.json({ status: "ok", mode: "Legacy Mode Active" });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
