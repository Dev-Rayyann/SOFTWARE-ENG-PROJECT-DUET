import React, { useEffect, useState } from 'react';
import { 
  Users, 
  Database, 
  Server, 
  Activity, 
  TrendingUp,
  FileCode,
  ShieldCheck
} from 'lucide-react';
import { formatPKR } from '../lib/utils';
import { Employee, PayrollRecord } from '../types';

export function DashboardHome() {
  const [stats, setStats] = useState({
    totalEmployees: 0,
    totalPayroll: 0,
    totalExpenses: 0,
    systemStatus: "Legacy Mode Active"
  });

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [empRes, payRes] = await Promise.all([
          fetch('/api/employees'),
          fetch('/api/payroll')
        ]);
        const employees: Employee[] = await empRes.json();
        const payroll: PayrollRecord[] = await payRes.json();
        
        const expenses = payroll.reduce((acc, curr) => acc + curr.netSalary, 0);
        
        setStats({
          totalEmployees: employees.length,
          totalPayroll: payroll.length,
          totalExpenses: expenses,
          systemStatus: "Legacy Mode Active"
        });
      } catch (error) {
        console.error("Error fetching stats:", error);
      }
    };
    fetchData();
  }, []);

  return (
    <div className="p-8 space-y-8 animate-in fade-in duration-500">
      <div className="flex flex-col gap-1">
        <h1 className="text-3xl font-mono font-bold tracking-tighter">Command Center</h1>
        <p className="text-sm text-gray-500 font-mono italic">Overview of reverse-engineered payroll architecture</p>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {[
          { label: 'Total Employees', value: stats.totalEmployees, icon: Users, color: 'text-blue-600' },
          { label: 'Payroll Records', value: stats.totalPayroll, icon: Database, color: 'text-orange-600' },
          { label: 'Total Expenses', value: formatPKR(stats.totalExpenses), icon: TrendingUp, color: 'text-green-600' },
          { label: 'System Mode', value: stats.systemStatus, icon: Server, color: 'text-purple-600' },
        ].map((stat, i) => (
          <div key={i} className="bg-white p-6 border border-[#E5E5E5] rounded-none hover:border-[#141414] transition-colors group">
            <div className="flex justify-between items-start mb-4">
              <span className="text-[10px] font-mono font-bold text-gray-400 uppercase tracking-widest">{stat.label}</span>
              <stat.icon className={cn("w-5 h-5", stat.color)} />
            </div>
            <div className="text-2xl font-mono font-bold tracking-tighter truncate">
              {stat.value}
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="bg-[#141414] text-[#E4E3E0] p-8 border border-[#141414]">
          <div className="flex items-center gap-3 mb-6">
            <FileCode className="text-orange-500 w-6 h-6" />
            <h2 className="text-lg font-mono font-bold uppercase tracking-tighter">System Overview</h2>
          </div>
          <div className="space-y-4 font-mono text-sm text-gray-400 leading-relaxed">
            <p>
              The system is currently operating in <span className="text-orange-500 font-bold underline px-1">LEGACY REVERSE ENGINEERING MODE</span>. 
              Active decompilation of COBOL-style payroll logic is underway to map dependencies between 
              employee data structures and tax computation modules.
            </p>
            <div className="p-4 bg-[#222] border-l-4 border-orange-500">
              <span className="text-[10px] text-gray-500 block mb-2 uppercase">Kernel Log: 0x8842</span>
              <code className="text-xs text-green-400 break-all">
                INIT_DATABASE_SYNC... OK<br/>
                LOAD_REVERSE_ENGINE_V2... OK<br/>
                PKR_CURRENCY_MODULE... READY
              </code>
            </div>
          </div>
        </div>

        <div className="bg-white p-8 border border-[#E5E5E5]">
          <div className="flex items-center gap-3 mb-6">
            <ShieldCheck className="text-green-600 w-6 h-6" />
            <h2 className="text-lg font-mono font-bold uppercase tracking-tighter">Security & Audit</h2>
          </div>
          <div className="space-y-6">
            <div className="flex justify-between items-center pb-4 border-b border-gray-100 italic">
              <span className="text-sm font-mono text-gray-500 uppercase">Audit Trail</span>
              <span className="text-[10px] font-mono bg-green-100 text-green-800 px-2 py-0.5 rounded">Verifed</span>
            </div>
            <div className="space-y-4">
              {[
                { action: 'Database backup', time: '2m ago' },
                { action: 'Authorized root login', time: '15m ago' },
                { action: 'Logic analysis export', time: '1h ago' },
              ].map((log, i) => (
                <div key={i} className="flex justify-between items-center group cursor-pointer">
                  <span className="text-sm font-mono text-gray-800 group-hover:text-orange-600 transition-colors">{log.action}</span>
                  <span className="text-xs font-mono text-gray-400">{log.time}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

import { cn } from '../lib/utils';
