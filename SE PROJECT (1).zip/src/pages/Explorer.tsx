import React from 'react';
import { FileCode, Terminal, HelpCircle } from 'lucide-react';

const legacyCode = `
       IDENTIFICATION DIVISION.
       PROGRAM-ID. PAYROLL-CALC.
       
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01 EMP-NAME         PIC X(30).
       01 SALARY-BASE      PIC 9(7)V99.
       01 BONUS-AMT        PIC 9(6)V99.
       01 TAX-PCT          PIC V99.
       01 NET-PAY          PIC 9(8)V99.
       
       PROCEDURE DIVISION.
       1000-CALC-PAY.
           MULTIPLY SALARY-BASE BY TAX-PCT GIVING TAX-AMT.
           ADD SALARY-BASE TO BONUS-AMT GIVING GROSS-PAY.
           SUBTRACT TAX-AMT FROM GROSS-PAY GIVING NET-PAY.
           DISPLAY "CALCULATED PAY FOR: " EMP-NAME.
           DISPLAY "NET PKR: " NET-PAY.
           STOP RUN.
`;

export function Explorer() {
  return (
    <div className="p-8 space-y-8 animate-in slide-in-from-bottom-2 duration-500">
      <div className="flex flex-col gap-1">
        <h1 className="text-3xl font-mono font-bold tracking-tighter">Legacy System Explorer</h1>
        <p className="text-sm text-gray-500 font-mono italic">Decompiled pseudo-code from 1980s mainframe payroll system</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 bg-[#1a1a1a] rounded-lg overflow-hidden border border-[#333] shadow-2xl">
          <div className="bg-[#2a2a2a] px-4 py-2 border-b border-[#333] flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Terminal className="text-gray-400 w-4 h-4" />
              <span className="text-[10px] font-mono text-gray-400 uppercase tracking-widest font-bold">PAYROLL_V1.CBL</span>
            </div>
            <div className="flex gap-1.5">
              <div className="w-2.5 h-2.5 rounded-full bg-red-500 opacity-50" />
              <div className="w-2.5 h-2.5 rounded-full bg-yellow-500 opacity-50" />
              <div className="w-2.5 h-2.5 rounded-full bg-green-500 opacity-50" />
            </div>
          </div>
          <div className="p-6">
            <pre className="font-mono text-xs text-green-500 leading-relaxed overflow-x-auto selection:bg-green-500/20">
              {legacyCode}
            </pre>
          </div>
        </div>

        <div className="space-y-6">
          <div className="bg-white p-6 border border-[#E5E5E5]">
            <div className="flex items-center gap-3 mb-4">
              <HelpCircle className="text-blue-500 w-5 h-5" />
              <h3 className="font-mono font-bold text-xs uppercase tracking-wider">Logic Breakdown</h3>
            </div>
            <div className="space-y-4">
              {[
                { var: 'SALARY-BASE', desc: 'The fundamental contractual salary in PKR.' },
                { var: 'TAX-PCT', desc: 'Fixed percentage for withholding tax.' },
                { var: 'BONUS-AMT', desc: 'Variable component added after tax calculation (Legacy Rule).' }
              ].map((item, i) => (
                <div key={i} className="group">
                  <div className="text-[10px] font-mono font-bold text-blue-600 mb-1">{item.var}</div>
                  <p className="text-xs text-gray-600 font-mono leading-tight">{item.desc}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-orange-50 p-6 border border-orange-200">
            <h4 className="font-mono font-bold text-xs text-orange-800 uppercase mb-3 tracking-widest">Architectural Note</h4>
            <p className="text-xs text-orange-950 font-mono leading-relaxed">
              Note that the legacy implementation uses fixed-length <span className="font-bold">PIC X/9</span> formats. 
              Reverse engineering reveals that overflows in the <span className="italic">NET-PAY</span> buffer 
              were historically handled by truncating high-order bits.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
