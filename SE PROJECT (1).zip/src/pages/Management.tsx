import React, { useState, useEffect } from 'react';
import { Users, Plus, Trash2, Search, Filter, Database, Link as LinkIcon } from 'lucide-react';
import { formatPKR, cn } from '../lib/utils';
import { Employee, PayrollRecord } from '../types';

export function Management() {
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [payroll, setPayroll] = useState<PayrollRecord[]>([]);
  const [activeTab, setActiveTab] = useState<'employees' | 'payroll'>('employees');
  const [isAdding, setIsAdding] = useState(false);
  const [newEmp, setNewEmp] = useState({ name: '', department: 'Engineering', salary: '' });

  const fetchData = async () => {
    const [eRes, pRes] = await Promise.all([
      fetch('/api/employees'),
      fetch('/api/payroll')
    ]);
    setEmployees(await eRes.json());
    setPayroll(await pRes.json());
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleAddEmployee = async (e: React.FormEvent) => {
    e.preventDefault();
    await fetch('/api/employees', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...newEmp, salary: Number(newEmp.salary) })
    });
    setNewEmp({ name: '', department: 'Engineering', salary: '' });
    setIsAdding(false);
    fetchData();
  };

  const handleDeleteEmployee = async (id: string) => {
    await fetch(`/api/employees/${id}`, { method: 'DELETE' });
    fetchData();
  };

  const getEmployeeName = (id: string) => {
    return employees.find(e => e.id === id)?.name || 'Unknown';
  };

  return (
    <div className="p-8 space-y-8 animate-in fade-in duration-500">
      <div className="flex justify-between items-end">
        <div className="flex flex-col gap-1">
          <h1 className="text-3xl font-mono font-bold tracking-tighter">System Management</h1>
          <p className="text-sm text-gray-500 font-mono italic">Full CRUD access to reverse-engineered databases</p>
        </div>
        <div className="flex bg-[#141414] p-1 gap-1">
          <button 
            onClick={() => setActiveTab('employees')}
            className={cn(
              "px-4 py-2 font-mono text-[10px] uppercase font-bold tracking-widest transition-colors",
              activeTab === 'employees' ? "bg-[#E4E3E0] text-[#141414]" : "text-[#888] hover:text-white"
            )}
          >
            Employees
          </button>
          <button 
            onClick={() => setActiveTab('payroll')}
            className={cn(
              "px-4 py-2 font-mono text-[10px] uppercase font-bold tracking-widest transition-colors",
              activeTab === 'payroll' ? "bg-[#E4E3E0] text-[#141414]" : "text-[#888] hover:text-white"
            )}
          >
            Payroll Records
          </button>
        </div>
      </div>

      <div className="bg-white border border-[#E5E5E5] overflow-hidden">
        {activeTab === 'employees' ? (
          <div className="divide-y divide-gray-100">
            <div className="p-6 flex justify-between items-center bg-gray-50/50">
              <div className="flex items-center gap-4">
                <Search className="w-4 h-4 text-gray-400" />
                <input 
                  placeholder="Filter by name..." 
                  className="bg-transparent font-mono text-xs focus:outline-none w-64"
                />
              </div>
              <button 
                onClick={() => setIsAdding(!isAdding)}
                className="bg-orange-600 text-white px-4 py-2 flex items-center gap-2 font-mono text-[10px] font-bold uppercase tracking-widest hover:bg-orange-700 transition-colors"
              >
                <Plus className="w-3 h-3" />
                Add New Record
              </button>
            </div>

            {isAdding && (
              <form onSubmit={handleAddEmployee} className="p-6 bg-orange-50/30 grid grid-cols-1 md:grid-cols-4 gap-4 animate-in slide-in-from-top-2">
                <input 
                  required
                  placeholder="Employee Name"
                  value={newEmp.name}
                  onChange={e => setNewEmp({...newEmp, name: e.target.value})}
                  className="bg-white border border-gray-200 px-3 py-2 font-mono text-xs focus:border-orange-500 outline-none"
                />
                <select 
                  value={newEmp.department}
                  onChange={e => setNewEmp({...newEmp, department: e.target.value})}
                  className="bg-white border border-gray-200 px-3 py-2 font-mono text-xs focus:border-orange-500 outline-none"
                >
                  <option>Engineering</option>
                  <option>HR</option>
                  <option>Operations</option>
                  <option>Finance</option>
                </select>
                <input 
                  required
                  type="number"
                  placeholder="Base Salary (PKR)"
                  value={newEmp.salary}
                  onChange={e => setNewEmp({...newEmp, salary: e.target.value})}
                  className="bg-white border border-gray-200 px-3 py-2 font-mono text-xs focus:border-orange-500 outline-none"
                />
                <button type="submit" className="bg-[#141414] text-white font-mono text-[10px] font-bold uppercase py-2">Confirm Add</button>
              </form>
            )}

            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-gray-50 border-b border-gray-100">
                    <th className="px-6 py-4 font-mono text-[10px] font-bold text-gray-400 uppercase tracking-wider">ID</th>
                    <th className="px-6 py-4 font-mono text-[10px] font-bold text-gray-400 uppercase tracking-wider">Full Name</th>
                    <th className="px-6 py-4 font-mono text-[10px] font-bold text-gray-400 uppercase tracking-wider">Department</th>
                    <th className="px-6 py-4 font-mono text-[10px] font-bold text-gray-400 uppercase tracking-wider">Salary</th>
                    <th className="px-6 py-4 font-mono text-[10px] font-bold text-gray-400 uppercase tracking-wider text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {employees.map(emp => (
                    <tr key={emp.id} className="hover:bg-gray-50/80 transition-colors group">
                      <td className="px-6 py-4 font-mono text-[10px] text-gray-400">#{emp.id.slice(-4)}</td>
                      <td className="px-6 py-4 font-mono text-xs font-bold text-gray-800">{emp.name}</td>
                      <td className="px-6 py-4">
                        <span className="text-[10px] font-mono px-2 py-0.5 bg-blue-50 text-blue-700 border border-blue-100 rounded-full uppercase italic">
                          {emp.department}
                        </span>
                      </td>
                      <td className="px-6 py-4 font-mono text-xs text-gray-600">{formatPKR(emp.salary)}</td>
                      <td className="px-6 py-4 text-right">
                        <button 
                          onClick={() => handleDeleteEmployee(emp.id)}
                          className="p-2 text-gray-300 hover:text-red-500 transition-colors opacity-0 group-hover:opacity-100"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-gray-50 border-b border-gray-100">
                  <th className="px-6 py-4 font-mono text-[10px] font-bold text-gray-400 uppercase tracking-wider">TX_ID</th>
                  <th className="px-6 py-4 font-mono text-[10px] font-bold text-gray-400 uppercase tracking-wider">Employee</th>
                  <th className="px-6 py-4 font-mono text-[10px] font-bold text-gray-400 uppercase tracking-wider">Bonus</th>
                  <th className="px-6 py-4 font-mono text-[10px] font-bold text-gray-400 uppercase tracking-wider">Tax</th>
                  <th className="px-6 py-4 font-mono text-[10px] font-bold text-gray-400 uppercase tracking-wider">Net Result</th>
                  <th className="px-6 py-4 font-mono text-[10px] font-bold text-gray-400 uppercase tracking-wider text-right">Timestamp</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {payroll.map(record => (
                  <tr key={record.id} className="hover:bg-gray-50/80 transition-colors">
                    <td className="px-6 py-4 font-mono text-[10px] text-gray-400">TRX-{record.id.slice(-4)}</td>
                    <td className="px-6 py-4 font-mono text-xs font-bold text-gray-800">{getEmployeeName(record.employeeId)}</td>
                    <td className="px-6 py-4 font-mono text-xs text-green-600">+{formatPKR(record.bonus)}</td>
                    <td className="px-6 py-4 font-mono text-xs text-red-600">-{formatPKR(record.tax)}</td>
                    <td className="px-6 py-4 font-mono text-sm font-bold text-gray-900 underline decoration-orange-500/30 underline-offset-4">{formatPKR(record.netSalary)}</td>
                    <td className="px-6 py-4 text-right font-mono text-[10px] text-gray-400">
                      {new Date(record.timestamp).toLocaleTimeString()}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      <div className="flex gap-6">
        <div className="flex-1 bg-[#141414] p-6 border-l-4 border-blue-500">
          <div className="flex items-center gap-2 mb-2">
            <Database className="w-4 h-4 text-blue-500" />
            <span className="text-[10px] font-mono text-gray-500 uppercase tracking-widest">Database Health</span>
          </div>
          <div className="text-white font-mono text-xs">
            RELATIONAL SYNC: <span className="text-green-500">OPTIMAL</span> • FRAG: 2.1%
          </div>
        </div>
        <div className="flex-1 bg-[#141414] p-6 border-l-4 border-orange-500">
          <div className="flex items-center gap-2 mb-2">
            <LinkIcon className="w-4 h-4 text-orange-500" />
            <span className="text-[10px] font-mono text-gray-500 uppercase tracking-widest">API Integrations</span>
          </div>
          <div className="text-white font-mono text-xs">
            ENDPOINT /employees: <span className="text-green-500">200 OK</span>
          </div>
        </div>
      </div>
    </div>
  );
}
