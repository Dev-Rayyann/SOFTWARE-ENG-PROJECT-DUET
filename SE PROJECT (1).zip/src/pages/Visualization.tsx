import React from 'react';
import { GitBranch, CornerDownRight, Database, Server, Calculator, UserCheck } from 'lucide-react';
import { motion } from 'motion/react';

export function Visualization() {
  const steps = [
    { 
      label: 'Employee Input', 
      icon: UserCheck, 
      desc: 'Retrieves personnel data from DB',
      fields: ['ID', 'Base Salary', 'Status'] 
    },
    { 
      label: 'Payroll Engine', 
      icon: Calculator, 
      desc: 'LEGACY-PROC-1000 Execution',
      fields: ['Tax Logic', 'Bonus Map'] 
    },
    { 
      label: 'Net Salary Output', 
      icon: Database, 
      desc: 'Validation and Persistence',
      fields: ['PKR Store', 'System Logs'] 
    }
  ];

  return (
    <div className="p-8 space-y-8 animate-in zoom-in-95 duration-500">
      <div className="flex flex-col gap-1">
        <h1 className="text-3xl font-mono font-bold tracking-tighter">Data Flow Visualization</h1>
        <p className="text-sm text-gray-500 font-mono italic">End-to-end mapping of payroll processing pipeline</p>
      </div>

      <div className="bg-white border border-[#E5E5E5] p-12 min-h-[500px] flex flex-col justify-center items-center relative overflow-hidden">
        {/* Background Grid Pattern */}
        <div className="absolute inset-0 opacity-[0.03] pointer-events-none" 
          style={{ backgroundImage: 'radial-gradient(#000 1px, transparent 1px)', backgroundSize: '20px 20px' }} 
        />

        <div className="flex flex-col md:flex-row items-center justify-between w-full max-w-4xl relative z-10 gap-12">
          {steps.map((step, idx) => (
            <React.Fragment key={idx}>
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.2 }}
                className="flex flex-col items-center gap-6 w-full max-w-[200px]"
              >
                <div className="w-20 h-20 bg-[#141414] rounded-full flex items-center justify-center shadow-lg group hover:scale-110 transition-transform cursor-pointer relative">
                  <step.icon className="w-8 h-8 text-orange-500" />
                  <div className="absolute -top-1 -right-1 bg-white border border-gray-200 text-[8px] font-mono px-1.5 py-0.5 rounded text-gray-500 shadow-sm">
                    MOD_{idx + 1}
                  </div>
                </div>

                <div className="text-center space-y-2">
                  <h3 className="font-mono font-bold text-sm tracking-tighter uppercase">{step.label}</h3>
                  <p className="text-[10px] text-gray-400 font-mono italic leading-tight px-4">{step.desc}</p>
                </div>

                <div className="w-full bg-gray-50 border border-gray-100 p-3 rounded-sm space-y-1">
                  {step.fields.map((f, i) => (
                    <div key={i} className="flex items-center gap-2 text-[9px] font-mono text-gray-500">
                      <div className="w-1 h-1 bg-blue-500 rounded-full" />
                      {f}
                    </div>
                  ))}
                </div>
              </motion.div>

              {idx < steps.length - 1 && (
                <div className="hidden md:flex flex-1 h-[1px] bg-gray-200 relative">
                  <motion.div 
                    initial={{ left: 0 }}
                    animate={{ left: '100%' }}
                    transition={{ repeat: Infinity, duration: 2, ease: "linear" }}
                    className="absolute top-1/2 -translate-y-1/2 w-4 h-[2px] bg-orange-500 shadow-[0_0_8px_rgba(249,115,22,0.8)]"
                  />
                  <CornerDownRight className="absolute -right-2 -top-2 w-4 h-4 text-gray-300" />
                </div>
              )}
            </React.Fragment>
          ))}
        </div>

        <div className="mt-16 w-full max-w-4xl">
          <div className="bg-[#141414] p-6 border-l-4 border-orange-500 flex justify-between items-center group">
            <div className="space-y-1">
              <span className="text-[10px] font-mono text-gray-500 uppercase tracking-widest">Active Process Status</span>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
                <span className="text-xs font-mono text-[#E4E3E0] uppercase font-bold tracking-tighter italic">Streaming Real-time Analytics</span>
              </div>
            </div>
            <Server className="w-5 h-5 text-gray-700 group-hover:text-orange-500 transition-colors" />
          </div>
        </div>
      </div>
    </div>
  );
}
