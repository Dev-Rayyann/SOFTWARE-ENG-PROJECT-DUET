import React, { useState } from 'react';
import { Cpu, Search, Layers, Box, Link2, Info } from 'lucide-react';
import { motion } from 'motion/react';

export function Analyzer() {
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  const startAnalysis = () => {
    setIsAnalyzing(true);
    setTimeout(() => setIsAnalyzing(false), 2000);
  };

  return (
    <div className="p-8 space-y-8 animate-in slide-in-from-right-2 duration-500">
      <div className="flex justify-between items-end">
        <div className="flex flex-col gap-1">
          <h1 className="text-3xl font-mono font-bold tracking-tighter">RE Analyzer</h1>
          <p className="text-sm text-gray-500 font-mono italic">Module-level dependency analysis and variable mapping</p>
        </div>
        <button 
          onClick={startAnalysis}
          disabled={isAnalyzing}
          className="bg-[#141414] text-white px-6 py-2 font-mono text-xs font-bold uppercase tracking-widest flex items-center gap-2 hover:bg-orange-600 transition-colors disabled:bg-gray-400 group"
        >
          {isAnalyzing ? (
            <Activity className="w-4 h-4 animate-spin" />
          ) : (
            <Search className="w-4 h-4 group-hover:scale-110 transition-transform" />
          )}
          {isAnalyzing ? "Processing..." : "Run Analysis"}
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="bg-white border border-[#E5E5E5] p-6 space-y-6">
          <div className="flex items-center gap-2 mb-4 border-b pb-4">
            <Layers className="text-orange-500 w-5 h-5" />
            <h2 className="font-mono font-bold text-sm uppercase">Identified Variables</h2>
          </div>
          <div className="grid grid-cols-1 gap-3">
            {[
              { id: 'V-001', name: 'SALARY-BASE', type: 'DECIMAL (7,2)', dep: 'None' },
              { id: 'V-002', name: 'TAX-AMT', type: 'DECIMAL (7,2)', dep: 'V-001 * V-004' },
              { id: 'V-003', name: 'BONUS-AMT', type: 'DECIMAL (6,2)', dep: 'Input' },
              { id: 'V-004', name: 'TAX-PCT', type: 'DECIMAL (0,2)', dep: 'Config' },
            ].map((v, i) => (
              <div key={i} className="flex items-center justify-between p-3 bg-gray-50 border border-transparent hover:border-gray-300 transition-all group">
                <div>
                  <div className="text-[10px] font-mono text-gray-400 mb-1">{v.id}</div>
                  <div className="text-xs font-mono font-bold">{v.name}</div>
                </div>
                <div className="text-right">
                  <div className="text-[10px] font-mono text-gray-500">{v.type}</div>
                  <div className="text-[10px] font-mono text-orange-600 italic">Dep: {v.dep}</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-[#141414] text-[#E4E3E0] p-6 space-y-6">
          <div className="flex items-center gap-2 mb-4 border-b border-[#333] pb-4">
            <Box className="text-blue-500 w-5 h-5" />
            <h2 className="font-mono font-bold text-sm uppercase">Component Dependencies</h2>
          </div>
          <div className="space-y-4">
            {[
              { label: 'Input Module', status: 'Decoupled', risk: 'Low' },
              { label: 'Tax Engine', status: 'Hardcoded', risk: 'High' },
              { label: 'Currency Formatter', status: 'Embedded', risk: 'Medium' },
            ].map((c, i) => (
              <div key={i} className="p-4 bg-[#222] flex justify-between items-center relative overflow-hidden group">
                <div className="z-10">
                  <div className="text-xs font-mono font-bold uppercase tracking-wider mb-1">{c.label}</div>
                  <div className="text-[10px] font-mono text-gray-500">Stability: {c.status}</div>
                </div>
                <div className={cn(
                  "text-[10px] font-mono px-2 py-1 z-10",
                  c.risk === 'High' ? 'bg-red-500/20 text-red-500 border border-red-500/50' : 
                  c.risk === 'Medium' ? 'bg-yellow-500/20 text-yellow-500 border border-yellow-500/50' : 
                  'bg-green-500/20 text-green-500 border border-green-500/50'
                )}>
                  RISK: {c.risk}
                </div>
                <div className="absolute top-0 right-0 w-24 h-full bg-gradient-to-l from-orange-500/5 to-transparent skew-x-12 translate-x-12 group-hover:translate-x-0 transition-transform duration-500" />
              </div>
            ))}
          </div>
          <div className="p-4 bg-blue-500/10 border border-blue-500/20 flex gap-4 items-start">
            <Info className="w-5 h-5 text-blue-500 shrink-0" />
            <p className="text-[10px] font-mono text-blue-300 leading-tight">
              Reverse engineering indicates a <span className="text-white font-bold underline">Monolithic Tightly Coupled Architecture</span>. 
              Refactoring recommended for migration to modern cloud-native systems.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

import { cn } from '../lib/utils';
import { Activity } from 'lucide-react';
