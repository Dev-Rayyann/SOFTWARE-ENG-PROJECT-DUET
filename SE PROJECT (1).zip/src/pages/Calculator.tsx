import React, { useState, useEffect } from 'react';
import { Calculator, Save, AlertCircle, CheckCircle2, ChevronRight, User } from 'lucide-react';
import { formatPKR, cn } from '../lib/utils';
import { Employee } from '../types';

export function CalculatorTool() {
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [selectedEmp, setSelectedEmp] = useState<string>('');
  const [basicSalary, setBasicSalary] = useState<string>('0');
  const [bonus, setBonus] = useState<string>('0');
  const [tax, setTax] = useState<string>('0');
  const [netSalary, setNetSalary] = useState<number | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);

  useEffect(() => {
    fetch('/api/employees')
      .then(res => res.json())
      .then(data => {
        setEmployees(data);
        if (data.length > 0) {
          setSelectedEmp(data[0].id);
          setBasicSalary(data[0].salary.toString());
        }
      });
  }, []);

  const handleCalculate = () => {
    const net = Number(basicSalary) + Number(bonus) - Number(tax);
    setNetSalary(net);
  };

  const handleSave = async () => {
    setIsSaving(true);
    try {
      const response = await fetch('/api/calculate-salary', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          employeeId: selectedEmp,
          basicSalary: Number(basicSalary),
          bonus: Number(bonus),
          tax: Number(tax)
        })
      });
      if (response.ok) {
        setShowSuccess(true);
        setTimeout(() => setShowSuccess(false), 3000);
      }
    } catch (error) {
      console.error("Save failed:", error);
    } finally {
      setIsSaving(false);
    }
  };

  const handleEmpChange = (id: string) => {
    setSelectedEmp(id);
    const emp = employees.find(e => e.id === id);
    if (emp) setBasicSalary(emp.salary.toString());
  };

  return (
    <div className="p-8 space-y-8 animate-in slide-in-from-left-2 duration-500">
      <div className="flex flex-col gap-1">
        <h1 className="text-3xl font-mono font-bold tracking-tighter">Payroll Calculator</h1>
        <p className="text-sm text-gray-500 font-mono italic">Execute real-time net salary computations with PKR localization</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="bg-white border border-[#E5E5E5] p-8 space-y-6">
          <div className="flex items-center gap-3 mb-4 border-b pb-4">
            <Calculator className="text-orange-500 w-5 h-5" />
            <h3 className="font-mono font-bold text-xs uppercase tracking-wider">Computation Form</h3>
          </div>

          <div className="space-y-4">
            <div className="space-y-2">
              <label className="text-[10px] font-mono font-bold text-gray-400 uppercase tracking-widest">Select Employee</label>
              <div className="relative">
                <select 
                  value={selectedEmp}
                  onChange={(e) => handleEmpChange(e.target.value)}
                  className="w-full bg-gray-50 border border-gray-200 px-4 py-3 font-mono text-sm appearance-none focus:outline-none focus:border-[#141414] transition-colors"
                >
                  {employees.map(emp => (
                    <option key={emp.id} value={emp.id}>{emp.name} ({emp.department})</option>
                  ))}
                </select>
                <ChevronRight className="absolute right-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400 rotate-90" />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-[10px] font-mono font-bold text-gray-400 uppercase tracking-widest">Basic Salary (PKR)</label>
                <input 
                  type="number" 
                  value={basicSalary}
                  onChange={(e) => setBasicSalary(e.target.value)}
                  className="w-full bg-gray-50 border border-gray-200 px-4 py-3 font-mono text-sm focus:outline-none focus:border-[#141414]"
                />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-mono font-bold text-gray-400 uppercase tracking-widest">Bonus (PKR)</label>
                <input 
                  type="number" 
                  value={bonus}
                  onChange={(e) => setBonus(e.target.value)}
                  className="w-full bg-gray-50 border border-gray-200 px-4 py-3 font-mono text-sm focus:outline-none focus:border-[#141414]"
                />
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-[10px] font-mono font-bold text-gray-400 uppercase tracking-widest">Tax Deduction (PKR)</label>
              <input 
                type="number" 
                value={tax}
                onChange={(e) => setTax(e.target.value)}
                className="w-full bg-gray-50 border border-gray-200 px-4 py-3 font-mono text-sm focus:outline-none focus:border-[#141414]"
              />
            </div>

            <button 
              onClick={handleCalculate}
              className="w-full bg-orange-600 text-white py-4 font-mono font-bold uppercase tracking-widest text-xs hover:bg-orange-700 transition-colors shadow-lg shadow-orange-600/10"
            >
              Execute Calculation
            </button>
          </div>
        </div>

        <div className="flex flex-col gap-6">
          <div className="bg-[#141414] text-[#E4E3E0] p-8 flex-1 flex flex-col justify-center items-center relative overflow-hidden border border-[#141414]">
            {netSalary !== null ? (
              <>
                <span className="text-[10px] font-mono text-gray-500 uppercase tracking-[0.2em] mb-4">Calculated Net Result</span>
                <div className="text-5xl font-mono font-bold text-white tracking-tighter mb-2">
                  {formatPKR(netSalary)}
                </div>
                <div className="h-[1px] w-32 bg-orange-500 mb-8 opacity-50" />
                
                <button 
                  onClick={handleSave}
                  disabled={isSaving}
                  className="bg-white/10 hover:bg-white/20 text-[#E4E3E0] border border-white/20 px-8 py-3 font-mono text-xs uppercase tracking-widest transition-all flex items-center gap-3 group"
                >
                  <Save className={cn("w-4 h-4", isSaving && "animate-spin")} />
                  {isSaving ? "Persisting..." : "Save to Ledger"}
                </button>
              </>
            ) : (
              <div className="text-center space-y-4">
                <AlertCircle className="w-12 h-12 text-[#333] mx-auto" />
                <p className="text-xs font-mono text-gray-500 uppercase tracking-widest italic">Awaiting Module Input</p>
              </div>
            )}

            {/* Corner Decorative */}
            <div className="absolute -bottom-4 -right-4 w-24 h-24 bg-orange-500/5 rotate-45" />
          </div>

          {showSuccess && (
            <div className="bg-green-600 text-white p-4 flex items-center gap-3 animate-in fade-in slide-in-from-top-1 duration-300">
              <CheckCircle2 className="w-5 h-5" />
              <span className="text-xs font-mono font-bold uppercase tracking-wider">Record Synchronized Successfully</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
