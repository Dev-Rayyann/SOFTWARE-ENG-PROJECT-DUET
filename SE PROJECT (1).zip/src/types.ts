export interface Employee {
  id: string;
  name: string;
  department: string;
  salary: number;
}

export interface PayrollRecord {
  id: string;
  employeeId: string;
  bonus: number;
  tax: number;
  netSalary: number;
  timestamp: string;
}

export interface SystemStatus {
  status: string;
  mode: string;
}
