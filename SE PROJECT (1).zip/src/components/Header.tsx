import React from 'react';
import { Terminal, Shield, Activity } from 'lucide-react';

export function Header() {
  return (
    <header className="h-16 bg-white border-b border-[#E5E5E5] flex items-center justify-between px-8 sticky top-0 z-10">
      <div className="flex items-center gap-4">
        <h2 className="text-sm font-mono font-bold text-[#141414] uppercase tracking-tighter">
          Payroll Reverse Engineering Dashboard
        </h2>
        <div className="h-4 w-[1px] bg-[#E5E5E5]" />
        <div className="flex items-center gap-2 text-[10px] font-medium text-green-600 bg-green-50 px-2 py-0.5 rounded-full border border-green-100">
          <Activity className="w-3 h-3" />
          SYSTEM STABLE
        </div>
      </div>

      <div className="flex items-center gap-6">
        <div className="flex items-center gap-2 text-xs font-mono text-[#555]">
          <Shield className="w-4 h-4 text-orange-500" />
          <span>Admin Session: <span className="text-black font-bold">RAY-X-99</span></span>
        </div>
        <div className="text-[10px] font-mono text-[#AAA]">
          TZ: PK/KST • 24.04.2026
        </div>
      </div>
    </header>
  );
}
