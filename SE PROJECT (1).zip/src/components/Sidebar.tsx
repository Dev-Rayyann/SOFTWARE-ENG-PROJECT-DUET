import React from 'react';
import { 
  LayoutDashboard, 
  Terminal, 
  Cpu, 
  GitBranch, 
  Calculator, 
  Users,
  Settings,
  AlertCircle
} from 'lucide-react';
import { Link, useLocation } from 'react-router-dom';
import { cn } from '../lib/utils';

const navItems = [
  { icon: LayoutDashboard, label: 'Dashboard Home', path: '/' },
  { icon: Terminal, label: 'Legacy Explorer', path: '/explorer' },
  { icon: Cpu, label: 'RE Analyzer', path: '/analyzer' },
  { icon: GitBranch, label: 'Data Flow', path: '/flow' },
  { icon: Calculator, label: 'Payroll Calculator', path: '/calculator' },
  { icon: Users, label: 'Employees', path: '/management' },
];

export function Sidebar() {
  const location = useLocation();

  return (
    <div className="w-64 h-screen bg-[#141414] text-[#E4E3E0] border-r border-[#333] flex flex-col fixed left-0 top-0 overflow-y-auto z-10">
      <div className="p-6 border-bottom border-[#333]">
        <div className="flex items-center gap-3 mb-2">
          <Terminal className="text-orange-500 w-6 h-6" />
          <h1 className="font-mono text-xs font-bold tracking-tighter uppercase">
            PR-RE Dashboard v1.0
          </h1>
        </div>
        <div className="flex items-center gap-2 px-2 py-1 bg-orange-500/10 border border-orange-500/20 rounded">
          <div className="w-2 h-2 rounded-full bg-orange-500 animate-pulse" />
          <span className="text-[10px] font-mono text-orange-500 uppercase font-bold tracking-widest">
            Legacy Mode Active
          </span>
        </div>
      </div>

      <nav className="flex-1 px-4 py-6">
        <div className="space-y-1">
          {navItems.map((item) => {
            const isActive = location.pathname === item.path;
            const Icon = item.icon;
            return (
              <Link
                key={item.path}
                to={item.path}
                className={cn(
                  "flex items-center gap-3 px-4 py-3 text-sm font-mono transition-colors rounded-sm group",
                  isActive 
                    ? "bg-[#E4E3E0] text-[#141414]" 
                    : "text-[#888] hover:bg-[#222] hover:text-[#E4E3E0]"
                )}
              >
                <Icon className={cn("w-4 h-4", isActive ? "text-[#141414]" : "text-[#555] group-hover:text-orange-500")} />
                {item.label}
              </Link>
            );
          })}
        </div>
      </nav>

      <div className="p-6 border-t border-[#333]">
        <div className="flex items-center gap-3 text-[#555] text-xs font-mono">
          <AlertCircle className="w-4 h-4" />
          <span>System Integrity: 98.4%</span>
        </div>
      </div>
    </div>
  );
}
