/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { Sidebar } from './components/Sidebar';
import { Header } from './components/Header';
import { DashboardHome } from './pages/DashboardHome';
import { Explorer } from './pages/Explorer';
import { Analyzer } from './pages/Analyzer';
import { Visualization } from './pages/Visualization';
import { CalculatorTool } from './pages/Calculator';
import { Management } from './pages/Management';

export default function App() {
  return (
    <BrowserRouter>
      <div className="min-h-screen bg-[#F5F5F5] flex">
        <Sidebar />
        <div className="flex-1 ml-64 flex flex-col">
          <Header />
          <main className="flex-1">
            <Routes>
              <Route path="/" element={<DashboardHome />} />
              <Route path="/explorer" element={<Explorer />} />
              <Route path="/analyzer" element={<Analyzer />} />
              <Route path="/flow" element={<Visualization />} />
              <Route path="/calculator" element={<CalculatorTool />} />
              <Route path="/management" element={<Management />} />
            </Routes>
          </main>
          <footer className="p-6 text-center text-[10px] font-mono text-gray-400 border-t border-[#E5E5E5]">
            © 2026 LEGACY REVERSE ENGINEERING SYSTEM • PK_LOCAL_INSTANCE_02
          </footer>
        </div>
      </div>
    </BrowserRouter>
  );
}

